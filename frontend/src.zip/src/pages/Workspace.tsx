export default function Workspace() {

    return (

        <div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center">

            <h1 className="text-4xl font-bold">

                Repository Indexed ✅

            </h1>

        </div>

    );

}