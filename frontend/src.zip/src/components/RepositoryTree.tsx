import { useEffect, useState } from "react";
import { getTree } from "../services/repositoryService";

type Props = {
    onOpenFile: (path: string) => void;
};

export default function RepositoryTree({ onOpenFile }: Props) {
    const [files, setFiles] = useState<any[]>([]);

    useEffect(() => {
        async function load() {
            const data = await getTree();
            console.log("Tree:", data);
            setFiles(data.files);
        }

        load();
    }, []);

    return (
        <div>
            <h2>Repository</h2>

            {files.map((file) => (
                <button
                    key={file.path}
                    onClick={() => {
                        console.log("CLICKED:", file.path);
                        onOpenFile(file.path);
                    }}
                    style={{
                        display: "block",
                        marginBottom: "8px",
                        width: "100%",
                        textAlign: "left",
                    }}
                >
                    📄 {file.path}
                </button>
            ))}
        </div>
    );
}